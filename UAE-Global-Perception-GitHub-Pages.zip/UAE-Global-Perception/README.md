# UAE Global Perception

阿联酋国际议题词汇云与研究型可视化页面。

## 网站
GitHub Pages 发布目录：`docs/`，首页为 `docs/index.html`。

## 说明
当前页面使用 ECharts 与 wordcloud 扩展在浏览器端渲染；词汇权重为展示用人工权重，不代表全网真实词频或机构官方排名。正式研究请逐项核验原始报告。

## 发布
GitHub 仓库 Settings → Pages → Deploy from a branch → `main` → `/docs`。
